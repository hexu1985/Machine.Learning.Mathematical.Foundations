# ch19_2_1.py
import numpy as np

x = [66, 58, 25, 78, 58, 15, 120, 39, 82, 50]
print('平均消费金额 = {}'.format(np.mean(x)))




