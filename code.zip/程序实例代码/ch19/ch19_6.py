# ch19_6.py
import numpy as np

x = [66, 58, 25, 78, 58, 15, 120, 39, 82, 50]
print("标准偏差 : {0:6.2f}".format(np.std(x)))



