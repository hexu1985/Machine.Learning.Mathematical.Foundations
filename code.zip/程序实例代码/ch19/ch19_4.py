# ch19_4.py
import numpy as np

x = [66, 58, 25, 78, 58, 15, 120, 39, 82, 50]
print("变异数 : ",np.var(x))



