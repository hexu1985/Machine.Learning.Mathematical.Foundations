# ch9_3.py
from sympy import *

x = Symbol('x')
f = Symbol('f')
f = 3*(x-2)**2 - 2
root = solve(f)
print(root)












