# ch21_7.py
import numpy as np

A = np.matrix([[1, 2], [3, 4]])
B = np.matrix([[1, 0], [0, 1]])
print('A * B = {}'.format(A * B))
print('B * A = {}'.format(B * A))


 








