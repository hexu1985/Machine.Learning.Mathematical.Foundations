# ch21_2.py
import numpy as np

A = np.matrix([[1, 2, 3], [4, 5, 6]])

print('2 * A   = {}'.format(2 * A))
print('0.5 * A = {}'.format(0.5 * A))











