# ch21_5.py
import numpy as np

A = np.matrix([[1, 2, 1], [2, 1, 2]])
B = np.matrix([[30], [50], [20]])
print('A * B = {}'.format(A * B))


 








