# ch21_1.py
import numpy as np

A = np.matrix([[1, 2, 3], [4, 5, 6]])
B = np.matrix([[4, 5, 6], [7, 8, 9]])

print('A + B = {}'.format(A + B))
print('A - B = {}'.format(A - B))











