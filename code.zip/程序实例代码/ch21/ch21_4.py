# ch21_4.py
import numpy as np

A = np.matrix([[2, 3, 1], [3, 2, 5]])
B = np.matrix([[30, 50], [60, 80], [50, 60]])
print('A * B = {}'.format(A * B))


 








