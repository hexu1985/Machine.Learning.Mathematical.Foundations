# ch21_10.py
import numpy as np

A = np.array([[[1, 2],
                [3, 4]],
               [[5, 6],
                [7, 8]],
               [[9, 10],
                [11, 12]]])

print('{}'.format(A))
print('shape = {}'.format(np.shape(A)))






 








