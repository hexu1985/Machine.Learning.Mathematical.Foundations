# ch21_11.py
import numpy as np

A = np.array([[0, 2, 4, 6],
              [1, 3, 5, 7]])              
B = A.T
print('{}'.format(B))
C = np.transpose(A)
print('{}'.format(C))








 








