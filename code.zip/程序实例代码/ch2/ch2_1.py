# ch2_1.py
import math

print('pi = {}'.format(math.pi))
print('e  = {}'.format(math.e))





