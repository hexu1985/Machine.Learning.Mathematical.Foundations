# ch2_4.py
import math

print('pow(2, 3) = {}'.format(math.pow(2, 3)))
print('pow(2, 5) = {}'.format(math.pow(2, 5)))






