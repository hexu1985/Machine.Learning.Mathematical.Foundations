# ch2_6.py
import math

print('log2(4)       = {}'.format(math.log2(4)))
print('log10(100)    = {}'.format(math.log10(100)))
print('log(e)        = {}'.format(math.log(math.e)))
print('log(2, 4)     = {}'.format(math.log(4, 2)))
print('log(10, 100)  = {}'.format(math.log(100, 10)))





