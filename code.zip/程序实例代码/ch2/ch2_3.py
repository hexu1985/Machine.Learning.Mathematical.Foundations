# ch2_3.py
import math

print('gcd(16, 40) = {}'.format(math.gcd(16, 40)))
print('gcd(28, 56) = {}'.format(math.gcd(28, 63)))






