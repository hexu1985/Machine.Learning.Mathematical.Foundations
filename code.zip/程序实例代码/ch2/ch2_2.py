# ch2_2.py
import math

print('ceil(2.1)   = {}'.format(math.ceil(2.1)))
print('ceil(2.9)   = {}'.format(math.ceil(2.9)))
print('ceil(-2.1)  = {}'.format(math.ceil(-2.1)))
print('ceil(-2.9)  = {}'.format(math.ceil(-2.9)))
print('floor(2.1)  = {}'.format(math.floor(2.1)))
print('floor(2.9)  = {}'.format(math.floor(2.9)))
print('floor(-2.1) = {}'.format(math.floor(-2.1)))
print('floor(-2.9) = {}'.format(math.floor(-2.9)))





