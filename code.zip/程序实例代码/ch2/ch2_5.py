# ch2_5.py
import math

print('sqrt(4) = {}'.format(math.sqrt(4)))
print('sqrt(8) = {}'.format(math.sqrt(8)))






