# ch11_1.py
empty_dict = {}                      # 这是建立空字典
print("打印类 = ", type(empty_dict))
empty_set = set()                    # 这是建立空集合
print("打印类 = ", type(empty_set))

