# ch11_2.py
fruits1 = ['apple', 'orange', 'apple', 'banana', 'orange']
x = set(fruits1)                # 将列转成集合
fruits2 = list(x)               # 将集合转成列表
print("原先列表数据fruits1 = ", fruits1)
print("新的列表资料fruits2 = ", fruits2)







