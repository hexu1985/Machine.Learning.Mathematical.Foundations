# ch12_6.py
import itertools
n = {1, 2, 3, 4, 5}
A = set(itertools.combinations(n, 3))
print('组合 = {}'.format(len(A)))
for a in A:
    print(a)











