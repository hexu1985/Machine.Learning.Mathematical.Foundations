# ch1_20.py
import numpy as np

x1 = np.linspace(0, 10, num=11)     # 使用linspace()产生数组
print(type(x1), x1)
x2 = np.arange(0,11,1)              # 使用arange()产生数组
print(type(x2), x2)
x3 = np.arange(11)                  # 简化语法产生数组
print(type(x3), x3)









