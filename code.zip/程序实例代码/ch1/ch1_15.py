# ch1_15.py
import matplotlib.pyplot as plt
import matplotlib.image as img

fig = img.imread('out1_14.jpg')
plt.imshow(fig)
plt.show()


