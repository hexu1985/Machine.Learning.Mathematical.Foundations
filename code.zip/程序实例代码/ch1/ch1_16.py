# ch1_16.py
import matplotlib.pyplot as plt

plt.scatter(5, 5)
plt.show()


