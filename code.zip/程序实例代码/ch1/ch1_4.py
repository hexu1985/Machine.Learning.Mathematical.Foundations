# ch1_4.py
import matplotlib.pyplot as plt

squares = [0, 1, 4, 9, 16, 25, 36, 49, 64]
plt.plot(squares, lw=10)       # 列表squares数据是y轴的值, 线条宽度是10
plt.show()



