# ch13_3.py
from fractions import Fraction

x = Fraction(2, 7) * Fraction(1, 6)
y = Fraction(5, 7) * Fraction(2, 6)
p = x + y
print('第 1 位抽签的中奖机率 {}'.format(Fraction(2, 7)))
print('第 2 位抽签的中奖机率 {}'.format(p))







