# ch13_4.py
from fractions import Fraction

x = Fraction(5, 6)
p = 1 - (x**3)
print('连掷骰子不出现 5 的机率 {}'.format(p))
print('连掷骰子不出现 5 的机率 {}'.format(float(p)))







